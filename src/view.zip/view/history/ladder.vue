<template>
  <div class="main_seat">
    <div class="search flex0 flex-ac-sb">
      <el-form
        :inline="true"
        :model="formInline"
        class="demo-form-inline flex-c-c"
      >
        <el-form-item label="订单号">
          <el-input v-model="formInline.sn" placeholder="输入订单号" />
        </el-form-item>
        <el-form-item label="工位" prop="stationID">
          <el-select
            style="width: 100%"
            v-model="formInline.stationID"
            placeholder="选择工位"
          >
            <el-option
              v-for="(item, i) in stationList"
              :key="i"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="日期选择">
          <el-date-picker
            v-model="timeVal"
            type="datetimerange"
            range-separator="到"
            start-placeholder="开始时间"
            end-placeholder="结束时间"
            value-format="YYYY-MM-DD HH:mm:ss"
          />
        </el-form-item>
      </el-form>
      <div>
        <el-button type="primary" @click="onSubmit" round :icon="Search"
          >搜索</el-button
        >
      </div>
    </div>

    <div class="content flex1">
      <el-table
        class=""
        :data="tableData"
        :border="parentBorder"
        style="width: 100%"
      >
        <el-table-column type="expand">
          <template #default="props">
            <el-timeline :data-m="props">
              <el-timeline-item
                v-for="(item, idx) in 10"
                :key="idx"
                timestamp="2018/4/12"
                placement="top"
                :color="idx == 0 ? '#1aad19' : '#eee'"
              >
                <el-card>
                  <h4>Update Github template</h4>
                  <p>Tom committed 2018/4/12 20:46</p>
                </el-card>
              </el-timeline-item>
            </el-timeline>
          </template>
        </el-table-column>
        <el-table-column type="index" label="序号" width="85" align="center" />
        <el-table-column
          label="工单名称"
          prop="sn"
          width="120"
          align="center"
        />
        <el-table-column label="文件类型" prop="fileType" align="center" />
        <!-- <el-table-column label="文件地址" prop="filePath" /> -->
        <el-table-column label="文件预览" align="center">
          <template #default="{ row }">
            <el-image
              v-if="row.fileType == 'image'"
              style="width: 100px; height: 100px"
              :src="row.filePath"
              :preview-src-list="[row.filePath]"
              z-index="99999999"
            />
            <video
              v-if="row.fileType == 'video'"
              style="width: 100px; height: 100px"
              class="table_video"
              :src="row.filePath"
              @click="thatOn(row)"
            >
              浏览器不支持视频播放
            </video>
          </template>
        </el-table-column>
        <!-- <el-table-column label="状态">
          <template #default="{row}">
            <el-tag class="ml-2" type="success">完成</el-tag>
            <el-tag class="ml-2" type="info">未完成</el-tag>
            <el-tag class="ml-2" type="danger">错误</el-tag>
          </template>
        </el-table-column> -->

        <el-table-column label="创建时间" prop="createTime" align="center">
          <template #default="{ row }">
            {{ dateFormat("YYYY-mm-dd HH:MM:SS", new Date(row.createTime)) }}
          </template>
        </el-table-column>

        <el-table-column label="修改时间" prop="updateTime" align="center">
          <template #default="{ row }">
            {{ dateFormat("YYYY-mm-dd HH:MM:SS", new Date(row.updateTime)) }}
          </template>
        </el-table-column>
      </el-table>
    </div>
    <el-dialog v-model="dialogVisible" title="视频" width="40%">
      <video
        v-if="dialogVisible"
        style="max-width: 100%"
        :src="thatRow.filePath"
        controls="controls"
      ></video>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import { Search, Plus } from "@element-plus/icons-vue";
import { getPicVideo, addPicVideo, delPicVideo } from "@/api/ladder";
import { getStation } from "@/api/seat";

const tableData = ref([]);
const formInline = ref({});
const timeVal = ref([]);
const dialogVisible = ref(false);
const thatRow = ref({});
const stationList = ref([]); // 工位

const onSubmit = () => {
  getTable({
    ...formInline.value,
    startDate: timeVal.value[0],
    endDate: timeVal.value[0],
  });
};
const getTable = (params) => {
  getPicVideo({ ...params }).then((res) => {
    console.log(res);
    tableData.value = res.data;
  });
};
const thatOn = (row) => {
  dialogVisible.value = true;
  thatRow.value = row;
};
const getStationList = (data) => {
  getStation({ ...data }).then((res) => {
    console.log("工位：", res.data);
    stationList.value = res.data;
  });
};
getStationList();
const dateFormat = (fmt, date) => {
  let ret;
  const opt = {
    "Y+": date.getFullYear().toString(), // 年
    "m+": (date.getMonth() + 1).toString(), // 月
    "d+": date.getDate().toString(), // 日
    "H+": date.getHours().toString(), // 时
    "M+": date.getMinutes().toString(), // 分
    "S+": date.getSeconds().toString(), // 秒
    // 有其他格式化字符需求可以继续添加，必须转化成字符串
  };
  for (let k in opt) {
    ret = new RegExp("(" + k + ")").exec(fmt);
    if (ret) {
      fmt = fmt.replace(
        ret[1],
        ret[1].length == 1 ? opt[k] : opt[k].padStart(ret[1].length, "0")
      );
    }
  }
  return fmt;
};
getTable({});
</script>
<style lang="scss" scoped>
// .ei-flow-form .el-card__body {
//   // 解决大图预览其它地方层级穿透问题
//   z-index: initial !important;
// }

.main_seat {
  width: 100%;
  height: 100%;
  padding: 14px;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  .content {
    width: 100%;
    // height: 100%;
    overflow-y: scroll;
    :deep(.el-table) {
      .el-table__cell {
        //解决层级穿透 使得 子元素不与其产生新的层叠关系
        position: static;
      }
    }
  }
  .search {
    width: 100%;
    margin-bottom: 26px;
    border-bottom: 1px solid #eee;
    padding: 27px 0;

    .demo-form-inline {
      display: flex;
      align-items: center;

      .el-form-item {
        margin-bottom: 0;
      }
    }
    // height: 83px;
  }
  .footPage {
    width: 100%;
    margin-top: 10px;
  }
}
.ep-button {
  margin: 4px;
}
.ep-button + .ep-button {
  margin-left: 0;
  margin: 4px;
}
</style>
